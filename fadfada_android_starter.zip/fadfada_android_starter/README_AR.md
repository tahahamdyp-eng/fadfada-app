# فضفضة — بداية مشروع Android (Flutter + Firebase)

هذه ملفات بداية قابلة للتطوير، وليست APK جاهزاً للنشر. يلزم إعداد Firebase قبل تشغيل تسجيل الدخول أو حفظ المشاعر.

## المتطلبات
- تثبيت Flutter SDK وAndroid Studio على كمبيوتر.
- إنشاء مشروع Firebase.
- تثبيت FlutterFire CLI.

## إعداد Firebase
1. أنشئ مشروعاً في Firebase Console وأضف تطبيق Android باستخدام اسم الحزمة الذي ستختاره.
2. فعّل Authentication ثم فعّل Google وFacebook. إعداد Facebook يتطلب تطبيقاً من Meta وإضافة App ID وApp Secret في إعدادات Firebase؛ لا تضع الأسرار داخل التطبيق.
3. أنشئ Cloud Firestore.
4. من جهاز الكمبيوتر داخل مجلد المشروع شغّل:
   - `flutter pub get`
   - `dart pub global activate flutterfire_cli`
   - `flutterfire configure`
5. بعد أن ينشئ الأمر `lib/firebase_options.dart`، افتح `lib/main.dart` وأضف:
   `import 'firebase_options.dart';`
   ثم غيّر `Firebase.initializeApp()` إلى:
   `Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform)`
6. طبّق قواعد `firestore.rules` من Firebase Console بعد مراجعتها واختبارها.
7. شغّل `flutter run` على جهاز Android.

## مهم قبل الاستخدام العام
- تسجيل الدخول عبر `signInWithProvider` قد يحتاج ضبطاً إضافياً بحسب إعدادات Android ومزوّد OAuth. اتبع تعليمات Firebase الخاصة بكل مزوّد.
- لا توجد في هذه النسخة لوحة مالك فعلية أو إرسال إشعارات إدارية بعد؛ لا يمكن تنفيذها بأمان داخل التطبيق وحده.
- لوحة المالك يجب أن تعتمد على صلاحية admin موثّقة من الخادم (مثل Firebase Custom Claims) وعلى Cloud Functions لحساب الإحصائيات. لا تعتمد على إخفاء زر لوحة التحكم فقط.
- استخدم Firebase Cloud Messaging مع Cloud Functions لإرسال إشعارات مجمّعة للمالك، مثل إجمالي عدد المستخدمين أو عدد اختيارات المشاعر يومياً. لا ترسل أسماء الأشخاص مع حالتهم النفسية ولا محتوى الفضفضة.
- أضف سياسة خصوصية واضحة وموافقة المستخدم قبل جمع بيانات المشاعر. لا تجعل بيانات المشاعر متاحة للمالك على مستوى الأفراد.
- اختبر قواعد Firestore بحسابين مختلفين قبل نشر التطبيق.

## الموجود حالياً
- واجهة عربية من اليمين لليسار.
- أزرار تسجيل دخول Google وFacebook عبر Firebase OAuth (تحتاج إعداد المزودين).
- حفظ اختيار المزاج في Firestore.
- بداية قواعد خصوصية تجعل سجل المشاعر خاصاً بصاحبه.
- شاشة رئيسية أولية قابلة للتصميم والتطوير.

## بناء APK بعد الإعداد
`flutter build apk --release`
الملف الناتج عادةً: `build/app/outputs/flutter-apk/app-release.apk`
