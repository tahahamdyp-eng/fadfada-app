import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // After running `flutterfire configure`, uncomment the generated options import
  // and pass DefaultFirebaseOptions.currentPlatform to Firebase.initializeApp().
  await Firebase.initializeApp();
  runApp(const FadfadaApp());
}

class FadfadaApp extends StatelessWidget {
  const FadfadaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'فضفضة',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6C63FF)),
        scaffoldBackgroundColor: const Color(0xFFF7F6FC),
        fontFamily: 'Arial',
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snapshot.data == null) return const SignInPage();
        return const HomePage();
      },
    );
  }
}

class SignInPage extends StatefulWidget {
  const SignInPage({super.key});

  @override
  State<SignInPage> createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  bool busy = false;

  Future<void> providerSignIn(String providerId) async {
    setState(() => busy = true);
    try {
      final provider = OAuthProvider(providerId);
      final result = await FirebaseAuth.instance.signInWithProvider(provider);
      final user = result.user;
      if (user != null) {
        await FirebaseFirestore.instance.collection('users').doc(user.uid).set({
          'uid': user.uid,
          'displayName': user.displayName,
          'email': user.email,
          'provider': providerId,
          'createdAt': FieldValue.serverTimestamp(),
          'lastSeenAt': FieldValue.serverTimestamp(),
        }, SetOptions(merge: true));
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذّر تسجيل الدخول: ${e.message ?? e.code}')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('راجع إعدادات Firebase وتسجيل الدخول أولاً')),
        );
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  Container(
                    width: 108, height: 108,
                    decoration: const BoxDecoration(
                      color: Color(0xFFE8E5FF), shape: BoxShape.circle),
                    child: const Icon(Icons.favorite_rounded, size: 58, color: Color(0xFF6C63FF)),
                  ),
                  const SizedBox(height: 20),
                  const Text('فضفضة', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text('مساحتك الآمنة للتعبير عن اللي جواك',
                      textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: Colors.black54)),
                  const SizedBox(height: 34),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: busy ? null : () => providerSignIn('google.com'),
                      icon: const Icon(Icons.g_mobiledata, size: 30),
                      label: const Text('المتابعة باستخدام Google'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: busy ? null : () => providerSignIn('facebook.com'),
                      icon: const Icon(Icons.facebook, size: 24),
                      label: const Text('المتابعة باستخدام Facebook'),
                      style: FilledButton.styleFrom(backgroundColor: const Color(0xFF1877F2)),
                    ),
                  ),
                  if (busy) const Padding(
                    padding: EdgeInsets.all(16),
                    child: CircularProgressIndicator(),
                  ),
                  const SizedBox(height: 22),
                  const Text(
                    'مشاعرك تخصّك. لن نعرض فضفضتك الخاصة لصاحب التطبيق.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  Future<void> saveMood(String mood) async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    await FirebaseFirestore.instance.collection('moodEvents').add({
      'uid': user.uid,
      'mood': mood,
      'createdAt': FieldValue.serverTimestamp(),
      'dayKey': DateTime.now().toIso8601String().substring(0, 10),
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('فضفضة'),
          actions: [
            IconButton(
              tooltip: 'تسجيل الخروج',
              onPressed: () => FirebaseAuth.instance.signOut(),
              icon: const Icon(Icons.logout),
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('أهلاً ${user?.displayName ?? 'بيك'} 💜',
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            const Text('عامل إيه النهارده؟ اختار إحساسك، من غير أي حكم عليك.'),
            const SizedBox(height: 24),
            MoodCard(
              title: 'أنا فرحان 😊',
              subtitle: 'سجّل إنك حاسس بفرحة النهارده',
              color: const Color(0xFFE2F7EA),
              onTap: () => saveMood('happy'),
            ),
            const SizedBox(height: 12),
            MoodCard(
              title: 'أنا زعلان 💙',
              subtitle: 'خد وقتك، ومشاعرك مهمة',
              color: const Color(0xFFE4EDFF),
              onTap: () => saveMood('sad'),
            ),
            const SizedBox(height: 12),
            MoodCard(
              title: 'حاسس بحاجة تانية 🌤️',
              subtitle: 'مش لازم تختار فرح أو زعل بس',
              color: const Color(0xFFFFEFD9),
              onTap: () => saveMood('other'),
            ),
            const SizedBox(height: 22),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'مهم: هذه نسخة بداية. يلزم إعداد Firebase وقواعد الأمان قبل استخدامها مع أشخاص حقيقيين. لوحة المالك والإحصائيات والإشعارات تحتاج إعداداً آمناً على الخادم.',
                  style: TextStyle(height: 1.5),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MoodCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const MoodCard({
    super.key,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: color,
      elevation: 0,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () async {
          try {
            await onTap();
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('تم تسجيل إحساسك. شكراً إنك شاركتنا 💜')),
              );
            }
          } catch (_) {
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('حصلت مشكلة. جرّب تاني بعد إعداد قاعدة البيانات.')),
              );
            }
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(subtitle),
                ],
              )),
              const Icon(Icons.arrow_back_ios_new_rounded),
            ],
          ),
        ),
      ),
    );
  }
}
